<script src="/js/admin.js"></script>
</body>
</html>