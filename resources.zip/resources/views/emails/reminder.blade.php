<div class="header" style="text-align: center;">
    <img src="{!! url('/images/logo.png') !!}" alt="logo" title="shop-sex.com.ua" width="228" height="60" />
    <p style="font-size: 20px;">Восстановление пароля</p>
</div>
<p>Для того, чтобы восстановить пароль, пожалуйста, перейдите по <a href="{{ url(' }}">данной</a> ссылке.</p>/lostpassword') . '?id=' . $user->id . '&code=' . $reminder->code