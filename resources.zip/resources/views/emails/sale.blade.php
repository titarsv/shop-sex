<div class="header" style="text-align: center;">
    <img src="{!! url('/images/logo.png') !!}" alt="logo" title="shop-sex.com.ua" width="228" height="60" />
    <p style="font-size: 20px;">Снижение цены на сайте shop-sex.com.ua!</p>
</div>