<div class="order-page__form-select-wrapper">
    <select name="payment" id="checkout-step__payment" class="order-page__form-select">
        <option disabled="" selected="">Выберите способ оплаты</option>
        <option value="cash">Наличными при самовывозе</option>
        <option value="prepayment">Предоплата</option>
    </select>
</div>