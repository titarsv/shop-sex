<div class="col-sm-12 col-xs-12 sales-banner-text-wrp">
    <div class="col-sm-4 col-xs-9 sales-banner-text">
        <h5>Sale 50%</h5>
        <p>Межсезонная распродажа</p>
    </div>
    <div class="col-sm-5 hidden-xs">
        <a href="{{env('APP_URL')}}/catalog/tovary/specpredlozhenija-rasprodazha" class="sales-banner-btn grid-products-banner">
            <p>Смотреть</p>
        </a>
    </div>
</div>